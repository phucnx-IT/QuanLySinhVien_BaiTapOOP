package cybersoft.backend.java16.view;

import java.util.Scanner;

import cybersoft.backend.java16.controler.QuanLyNhanSu;
import cybersoft.backend.java16.model.GiamDoc;
import cybersoft.backend.java16.model.NhanSu;
import cybersoft.backend.java16.model.NhanVien;
import cybersoft.backend.java16.model.TruongPhong;

public class QuanLyNhanSuConsole {
	private QuanLyNhanSu controller;
	private Scanner scan = new Scanner(System.in);

	public QuanLyNhanSuConsole() {
		this.controller = new QuanLyNhanSu();
	}

	public void start() {
		int option;
		do {
			inMenu();
			option = Integer.parseInt(scan.nextLine());
		} while (xuLyMenu(option));
	}

	public void inMenu() {
		System.out.println("--------------------------------***------------------------------");
		String text = String.format("|%-63s|", "Danh sách chức năng");
		System.out.println(text);
		text = String.format("|%-63s|", "1. Nhập thông tin công ty");
		System.out.println(text);
		text = String.format("|%-63s|", "2. In thông tin công ty");
		System.out.println(text);
		text = String.format("|%-63s|", "3. Thêm nhân sự");
		System.out.println(text);
		text = String.format("|%-63s|", "4. Xóa nhân sự");
		System.out.println(text);
		text = String.format("|%-63s|", "5. In danh sách nhân sự");
		System.out.println(text);
		text = String.format("|%-63s|", "6. Phân bổ nhân sự");
		System.out.println(text);
		text = String.format("|%-63s|", "7. Tính tổng lương toàn công ty");
		System.out.println(text);
		text = String.format("|%-63s|", "8. Tìm nhân viên thường có lương cao nhất");
		System.out.println(text);
		text = String.format("|%-63s|", "9. Tìm trưởng phòng có số lượng nhân viên dưới quyền nhiều nhất");
		System.out.println(text);
		text = String.format("|%-63s|", "10. Sắp xếp nhân viên theo thứ tự abc");
		System.out.println(text);
		text = String.format("|%-63s|", "11. Sắp xếp nhân viên theo thứ tự lương giảm dần");
		System.out.println(text);
		text = String.format("|%-63s|", "12. Tìm giám đốc có số lượng cổ phần nhiều nhất");
		System.out.println(text);
		text = String.format("|%-63s|", "13. Tính tổng thu nhập của giám đốc");
		System.out.println(text);
		text = String.format("|%-63s|", "0. Thoát chương trình");
		System.out.println(text);
		System.out.println("--------------------------------***------------------------------");
		System.out.print("Lựa chọn: ");
	}

	public boolean xuLyMenu(int option) {
		boolean isContinue = true;
		switch (option) {
		case 1: // Nhập thông tin công ty
			this.controller.duLieuTest();
			this.controller.nhapThongTinCongTy(scan);
			break;
		case 2: // Xuất thông tin công ty
			this.controller.xuatThongTinCongTy();
			break;
		case 3: // Thêm nhân sự
			themNhanSu();
			this.controller.tinhLuongThangToanBoNhanVien();
			break;
		case 4: // Xóa nhân sự
			xoaNhanSu();
			break;
		case 5: // In danh sách nhân sự
			this.controller.tinhLuongThangToanBoNhanVien();
			this.controller.xuatDanhSach();
			break;
		case 6: // Phân bổ nhân sự
			phanBoNhanSu();
			break;
		case 7:// Tính tống lương toàn công ty
			System.out.println("Tổng lương toàn công ty là: " + this.controller.tongLuongToanCongTy());
			break;
		case 8: // Tìm nhân viên thường có lương cao nhất
			this.controller.timNhanVienCoLuongCaoNhat();
			break;
		case 9: // Tìm trưởng phòng có số lượng nhân viên dưới quyền nhiều nhất
			this.controller.timTruongPhongCoNhanVienDuoiQuyenNhieuNhat();
			break;
		case 10: // Sắp xếp nhân viên theo thứ tự ABC
			this.controller.sapXepNhanVienTheoThuTuABC();
			this.controller.xuatDanhSach();
			break;
		case 11: // Sắp xếp nhân viên theo thứ tự lương giảm dần
			this.controller.sapXepNhanVienTheoLuongGiamDan();
			this.controller.xuatDanhSach();
			break;
		case 12: // Tìm giám đốc có số lượng cổ phần nhiều nhất
			this.controller.timGiamDocCoSoCoPhanNhieuNhat();
			break;
		case 13: // Tính tổng thu nhập của giám đốc
			this.controller.tinhThuNhapCuaTungGiamDoc();
			break;
		case 0:
			isContinue = false;
			break;
		default:
			System.out.println("Lựa chọn không hợp lệ !!");
			break;
		}
		return isContinue;
	}

	public void themNhanSu() {
		NhanSu nhansu;
		System.out.println("Loại nhân viên");
		System.out.println("1. Nhân viên");
		System.out.println("2. Trưởng phòng");
		System.out.println("3. Giám đốc");
		System.out.print("Vui lòng chọn: ");
		switch (Byte.parseByte(scan.nextLine())) {
		case 1:
			nhansu = new NhanVien();
			break;
		case 2:
			nhansu = new TruongPhong();
			break;
		case 3:
			nhansu = new GiamDoc();
			break;
		default:
			System.out.println("Loại nhân sự không hợp lệ");
			return;
		}
		nhansu.nhapThongTin(scan);
		controller.them(nhansu);
	}

	public void xoaNhanSu() {
		System.out.print("Nhập mã nhân sự cần xóa: ");
		String maNhanSu = scan.nextLine();
		if (controller.xoa(maNhanSu)) {
			System.out.println("Xóa thành công");
		} else {
			System.out.println("Không tìm thấy mã nhân sự cần xóa");
		}
	}

	public void phanBoNhanSu() {
		System.out.print("Nhập mã trưởng phòng muốn phân bổ nhân viên: ");
		String maTruongPhong = scan.nextLine();
		if (this.controller.phanBoNhanSuTheoMaTruongPhong(maTruongPhong)) {
			System.out.println("Phân bổ thành công");
		} else {
			System.out.println("Phân bổ không thành công");
		}
	}
}
