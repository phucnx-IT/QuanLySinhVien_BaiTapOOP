package cybersoft.backend.java16.model;

import java.util.Scanner;

public class GiamDoc extends NhanSu {
	// properties
	private byte soCoPhan;

	// get,set
	public byte getSoCoPhan() {
		return this.soCoPhan;
	}
	// constructors

	public GiamDoc(String maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay, byte soCoPhan) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		this.soCoPhan = soCoPhan;
	}

	public GiamDoc() {
		super();
	}

	// methods
	@Override
	public void nhapThongTin(Scanner scan) {
		super.nhapThongTin(scan);
		do {
			System.out.print("Số cổ phần (%): ");
			this.soCoPhan = Byte.parseByte(scan.nextLine());
		} while (this.soCoPhan > 100 || this.soCoPhan < 0);
	}

	@Override
	public void xuatThongTin() {
		super.xuatThongTin();
		String thongTin = new StringBuilder().append("\nSố cổ phần: ").append(this.soCoPhan).append("%").toString();
		System.out.println(thongTin);
	}

	@Override
	public void tinhLuongThang() {
		super.tinhLuongThang();
	}

}
