package cybersoft.backend.java16.model;

public class TruongPhong extends NhanSu {
	// constant
	final byte HE_SO_NHAN_VIEN = 100;
	// properties
	private int soNhanVien;

//get,set
	public String getHoTen() {
		return this.hoTen;
	}

	public void setSoNhanVien(int soNhanVien) {
		this.soNhanVien = soNhanVien;
	}

	public int getSoNhanVien() {
		return this.soNhanVien;
	}

//constructors
	public TruongPhong() {
		this.soNhanVien = 0;
	}

	public TruongPhong(String maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		// TODO Auto-generated constructor stub
	}

//methods
	public void tangNhanVien() {
		this.soNhanVien++;
	}

	public void giamNhanVien() {
		this.soNhanVien--;
	}

	@Override
	public void xuatThongTin() {
		super.xuatThongTin();
		System.out.println("\nSố nhân viên dưới quyền: " + this.soNhanVien);
	}

	@Override
	public void tinhLuongThang() {
		this.luongThang = this.luongMotNgay * this.soNgayLam + this.soNhanVien * HE_SO_NHAN_VIEN;
	}

}
