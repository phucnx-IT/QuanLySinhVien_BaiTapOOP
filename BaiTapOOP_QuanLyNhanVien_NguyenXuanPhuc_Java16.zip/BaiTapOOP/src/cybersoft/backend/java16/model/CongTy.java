package cybersoft.backend.java16.model;

import java.util.Scanner;

public class CongTy {
	// properties

	private String ten;
	private String maSoThue;
	private float doanhThuThang;

//get,set
	public float getDoanhThuThang() {
		return this.doanhThuThang;
	}

//constructors
//methods
	public void nhapThongTin(Scanner scan) {
		System.out.println("----Nhập thông tin công ty----");
		System.out.print("Tên công ty: ");
		this.ten = scan.nextLine();
		System.out.print("Nhập mã số thuế: ");
		this.maSoThue = scan.nextLine();
		System.out.print("Doanh thu tháng: ");
		this.doanhThuThang = Float.parseFloat(scan.nextLine());
	}

	public void xuatThongTin() {
		System.out.println("----Thông tin công ty----");
		System.out.println(new StringBuilder().append("Tên công ty: ").append(this.ten).append("\nMã số thuế: ")
				.append(this.maSoThue).append("\nDoanh thu tháng: ").append(this.doanhThuThang));
	}
}
