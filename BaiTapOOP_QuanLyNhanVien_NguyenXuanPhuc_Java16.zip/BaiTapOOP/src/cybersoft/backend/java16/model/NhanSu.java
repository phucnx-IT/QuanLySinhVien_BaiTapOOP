package cybersoft.backend.java16.model;

import java.util.Scanner;

public class NhanSu {
	// properties

	protected String maSo;
	protected String hoTen;
	protected String soDienThoai;
	protected float soNgayLam;
	protected float luongMotNgay;
	protected float luongThang;

//get,set
	public String getMaSo() {
		return this.maSo;
	}

	public float getLuongThang() {
		return this.luongThang;
	}

	public String getHoTen() {
		return this.hoTen;
	}

//constructors

	protected NhanSu(String maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		this.maSo = maSo;
		this.hoTen = hoTen;
		this.soDienThoai = soDienThoai;
		this.soNgayLam = soNgayLam;
		this.luongMotNgay = luongMotNgay;
	}

	protected NhanSu() {
		super();
	}

//methods
	public void nhapThongTin(Scanner scan) {
		System.out.println("----Nhập thông tin------");
		System.out.print("Nhập mã nhân viên: ");
		this.maSo = scan.nextLine();
		System.out.print("Nhập họ tên nhân viên: ");
		this.hoTen = scan.nextLine();
		System.out.print("Nhập số điện thoại: ");
		this.soDienThoai = scan.nextLine();
		System.out.print("Nhập số ngày làm: ");
		this.soNgayLam = Float.parseFloat(scan.nextLine());
		System.out.print("Nhập lương một ngày: ");
		this.luongMotNgay = Float.parseFloat(scan.nextLine());
	}

	public void xuatThongTin() {
		String thongTin = new StringBuilder().append("----Thông tin nhân sự----").append("\nMã số: ").append(this.maSo)
				.append("\tHọ tên: ").append(this.hoTen).append("\tSố điện thoại: ").append(this.soDienThoai)
				.append("\tSố ngày làm: ").append(this.soNgayLam).append("\tLương một ngày: ").append(this.luongMotNgay)
				.append("\tLương tháng: ").append(this.luongThang).toString();
		System.out.print(thongTin);
	}

	public void tinhLuongThang() {
		this.luongThang = this.luongMotNgay * this.soNgayLam;
	}
}
