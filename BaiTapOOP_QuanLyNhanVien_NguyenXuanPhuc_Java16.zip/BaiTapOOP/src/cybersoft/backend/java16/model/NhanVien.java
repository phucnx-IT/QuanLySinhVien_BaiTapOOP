package cybersoft.backend.java16.model;

public class NhanVien extends NhanSu {
	// constant
	final byte LUONG_MOT_NGAY = 100;
	// properties
	private TruongPhong truongPhongQuanLy;

//get,set
	public void setTruongPhongQuanLy(TruongPhong truongPhongQuanLy) {
		this.truongPhongQuanLy = truongPhongQuanLy;
	}

	public TruongPhong getTruongPhongQuanLy() {
		return this.truongPhongQuanLy;
	}

//constructors
	public NhanVien() {
		super();
		this.truongPhongQuanLy = null;
	}

	public NhanVien(String maSo, String hoTen, String soDienThoai, float soNgayLam, float luongMotNgay) {
		super(maSo, hoTen, soDienThoai, soNgayLam, luongMotNgay);
		// TODO Auto-generated constructor stub
	}

//methods
	@Override
	public void xuatThongTin() {
		super.xuatThongTin();
		if (this.truongPhongQuanLy != null) {
			System.out.println("\nTrưởng phòng quản lý: " + this.truongPhongQuanLy.getHoTen());
		} else {
			System.out.println("\nTrưởng phòng quản lý: Chưa phân bổ");
		}
	}

	@Override
	public void tinhLuongThang() {
		super.tinhLuongThang();
	}
}
