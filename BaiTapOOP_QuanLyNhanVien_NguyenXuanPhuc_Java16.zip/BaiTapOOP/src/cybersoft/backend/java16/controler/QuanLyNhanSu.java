package cybersoft.backend.java16.controler;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import cybersoft.backend.java16.model.CongTy;
import cybersoft.backend.java16.model.GiamDoc;
import cybersoft.backend.java16.model.NhanSu;
import cybersoft.backend.java16.model.NhanVien;
import cybersoft.backend.java16.model.TruongPhong;

public class QuanLyNhanSu {
	// Attributes
	private List<NhanSu> danhSachNhanSu;
	private CongTy congTy;
	private Scanner scan = new Scanner(System.in);
	private float loiNhuanCongTy;

//Constructors
	public QuanLyNhanSu() {
		danhSachNhanSu = new ArrayList<NhanSu>();
		congTy = new CongTy();
	}

//Methods
	public void nhapThongTinCongTy(Scanner scan) {
		congTy.nhapThongTin(scan);
	}

	public void xuatThongTinCongTy() {
		congTy.xuatThongTin();
	}

	public boolean them(NhanSu ns) {
		if (ns == null) {
			return false;
		}
		if (ns.getMaSo() == null || ("").equals(ns.getMaSo())) {
			return false;
		}
		return this.danhSachNhanSu.add(ns);
	}

	public boolean xoa(String maSo) {
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns.getMaSo().equalsIgnoreCase(maSo)) {
				xoaGiamDoc(ns);
				xoaNhanVien(ns);
				xoaTruongPhong(ns);
				return true;
			}
		}
		return false;
	}

	private void xoaTruongPhong(NhanSu ns) {
		if (ns instanceof TruongPhong) {
			for (NhanSu nhanVienCoTruongPhong : this.danhSachNhanSu) {
				if (nhanVienCoTruongPhong instanceof NhanVien) {
					if (((NhanVien) nhanVienCoTruongPhong).getTruongPhongQuanLy() == (TruongPhong) ns) {
						((NhanVien) nhanVienCoTruongPhong).setTruongPhongQuanLy(null);
					}
				}
			}
			this.danhSachNhanSu.remove(ns);
		}
	}

	private void xoaNhanVien(NhanSu ns) {
		if (ns instanceof NhanVien) {
			if (((NhanVien) ns).getTruongPhongQuanLy() != null) {
				TruongPhong tp = ((NhanVien) ns).getTruongPhongQuanLy();
				tp.giamNhanVien();
			}
			this.danhSachNhanSu.remove(ns);
		}
	}

	private void xoaGiamDoc(NhanSu ns) {
		if (ns instanceof GiamDoc) {
			this.danhSachNhanSu.remove(ns);
		}
	}

	public void xuatDanhSach() {
		for (NhanSu ns : this.danhSachNhanSu) {
			ns.xuatThongTin();
		}
	}

	public boolean phanBoNhanSuTheoMaTruongPhong(String maTP) {
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof TruongPhong) {
				if (ns.getMaSo().equalsIgnoreCase(maTP)) {
					if (kiemTraMaNhanVienPhanBo(ns))
						return true;
					else
						return false;
				} else {
					System.out.println("Không tìm thấy mã trưởng phòng muốn phân bổ");
					return false;
				}
			}
		}
		return false;
	}

	private boolean kiemTraMaNhanVienPhanBo(NhanSu ns) {
		System.out.print("Nhập mã nhân viên cần phân bổ: ");
		String maNhanVien = scan.nextLine();
		for (NhanSu ns1 : this.danhSachNhanSu) {
			if (ns1 instanceof NhanVien) {
				if (ns1.getMaSo().equals(maNhanVien)) {
					((NhanVien) ns1).setTruongPhongQuanLy((TruongPhong) ns);
					((TruongPhong) ns).tangNhanVien();
					return true;
				} else {
					System.out.println("Không tìm thấy mã nhân viên cần phân bổ");
					return false;
				}
			}
		}
		return false;
	}

	public float tongLuongToanCongTy() {
		float tongLuong = 0;
		for (NhanSu ns : this.danhSachNhanSu) {
			tongLuong += ns.getLuongThang();
		}
		return tongLuong;
	}

	public void timNhanVienCoLuongCaoNhat() {
		float luongCaoNhat = 0;
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof NhanVien) {
				if (ns.getLuongThang() > luongCaoNhat) {
					luongCaoNhat = ns.getLuongThang();
				}
			}
		}
		System.out.println("Danh sách nhân viên thường có lương cao nhất: ");
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof NhanVien) {
				if (ns.getLuongThang() == luongCaoNhat) {
					ns.xuatThongTin();
				}
			}
		}
	}

	public void timTruongPhongCoNhanVienDuoiQuyenNhieuNhat() {
		int nhanVienDuoiQuyen = 0;
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof TruongPhong) {
				if (((TruongPhong) ns).getSoNhanVien() > nhanVienDuoiQuyen) {
					nhanVienDuoiQuyen = ((TruongPhong) ns).getSoNhanVien();
				}
			}
		}
		System.out.println("Danh sách trưởng phòng có nhân viên dưới quyền nhiều nhất: ");
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof TruongPhong) {
				if (((TruongPhong) ns).getSoNhanVien() == nhanVienDuoiQuyen) {
					((TruongPhong) ns).xuatThongTin();
				}
			}
		}
	}

	public void sapXepNhanVienTheoThuTuABC() {
		for (int i = 0; i < this.danhSachNhanSu.size(); i++) {
			for (int j = 0; j < this.danhSachNhanSu.size(); j++) {
				NhanSu ns = this.danhSachNhanSu.get(i);
				NhanSu ns1 = this.danhSachNhanSu.get(j);
				if (ns.getHoTen().compareToIgnoreCase(ns1.getHoTen()) < 0) {
					Collections.swap(danhSachNhanSu, i, j);
				}
			}
		}
	}

	public void tinhLuongThangToanBoNhanVien() {
		for (NhanSu ns : this.danhSachNhanSu) {
			ns.tinhLuongThang();
		}
	}

	public void sapXepNhanVienTheoLuongGiamDan() {
		for (int i = 0; i < this.danhSachNhanSu.size(); i++) {
			for (int j = i + 1; j < this.danhSachNhanSu.size(); j++) {
				NhanSu ns = this.danhSachNhanSu.get(i);
				NhanSu ns1 = this.danhSachNhanSu.get(j);
				if (ns.getLuongThang() < ns1.getLuongThang()) {
					Collections.swap(danhSachNhanSu, i, j);
				}
			}
		}
	}

	public void timGiamDocCoSoCoPhanNhieuNhat() {
		byte coPhanLonNhat = 0;
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof GiamDoc) {
				if (((GiamDoc) ns).getSoCoPhan() > coPhanLonNhat) {
					coPhanLonNhat = ((GiamDoc) ns).getSoCoPhan();
				}
			}
		}
		System.out.println("Danh sách giám đốc có lượng cổ phần nhiều nhất");
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof GiamDoc) {
				if (((GiamDoc) ns).getSoCoPhan() == coPhanLonNhat) {
					((GiamDoc) ns).xuatThongTin();
				}
			}
		}
	}

	public void tinhThuNhapCuaTungGiamDoc() {
		float thuNhap = 0;
		this.loiNhuanCongTy = congTy.getDoanhThuThang() - tongLuongToanCongTy();
		for (NhanSu ns : this.danhSachNhanSu) {
			if (ns instanceof GiamDoc) {
				((GiamDoc) ns).xuatThongTin();
				thuNhap = ((GiamDoc) ns).getLuongThang() + (((GiamDoc) ns).getSoCoPhan() * this.loiNhuanCongTy) / 100;
				System.out.println("Thu nhập: " + thuNhap);
			}
		}
	}

	public void duLieuTest() {
		try {
			FileReader reader = new FileReader("src/NhanSu");
			BufferedReader bufferReader = new BufferedReader(reader);
			String line;
			while ((line = bufferReader.readLine()) != null) {
				String listInfo[] = line.split("#");
				NhanSu nhansu = null;
				if (listInfo[0].contains("NV")) {
					nhansu = new NhanVien(listInfo[0], listInfo[1], listInfo[2], Float.parseFloat(listInfo[3]),
							Float.parseFloat(listInfo[4]));
				} else if (listInfo[0].contains("TP")) {
					nhansu = new TruongPhong(listInfo[0], listInfo[1], listInfo[2], Float.parseFloat(listInfo[3]),
							Float.parseFloat(listInfo[4]));
				} else if (listInfo[0].contains("GD")) {
					nhansu = new GiamDoc(listInfo[0], listInfo[1], listInfo[2], Float.parseFloat(listInfo[3]),
							Float.parseFloat(listInfo[4]), Byte.parseByte(listInfo[5]));
				}
				this.danhSachNhanSu.add(nhansu);
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
