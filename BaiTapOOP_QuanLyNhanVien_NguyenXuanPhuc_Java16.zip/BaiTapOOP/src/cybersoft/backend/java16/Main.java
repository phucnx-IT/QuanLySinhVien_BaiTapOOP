package cybersoft.backend.java16;

import java.util.Scanner;

import cybersoft.backend.java16.model.GiamDoc;
import cybersoft.backend.java16.model.NhanSu;
import cybersoft.backend.java16.model.NhanVien;
import cybersoft.backend.java16.view.QuanLyNhanSuConsole;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		QuanLyNhanSuConsole program = new QuanLyNhanSuConsole();
		System.out.println("Chương trình quản lý nhân sự - Java16");
		program.start();
		System.out.println("Chương trình đã kết thúc !");
	}

}
